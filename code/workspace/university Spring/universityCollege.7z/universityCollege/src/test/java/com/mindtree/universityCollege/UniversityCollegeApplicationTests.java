package com.mindtree.universityCollege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityCollegeApplicationTests {

	@Test
	void contextLoads() {
	}

}

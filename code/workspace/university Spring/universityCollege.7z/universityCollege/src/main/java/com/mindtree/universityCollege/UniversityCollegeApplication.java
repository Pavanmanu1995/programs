package com.mindtree.universityCollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityCollegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityCollegeApplication.class, args);
	}

}

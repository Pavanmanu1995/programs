package functionalInterface;

@FunctionalInterface
public interface MyFunctionalInterface {
	public int add(int a, int b);
}

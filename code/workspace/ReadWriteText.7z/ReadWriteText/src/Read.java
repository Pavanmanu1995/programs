import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Read {

	public static void main(String[] args) {
		
		int id=1;
		String name="Pavan";
		FileWriter fileWriter=null;
		BufferedWriter bufferedWriter=null;
		PrintWriter printWriter=null;
		
		File file=new File(D/);
		fileWriter=new  

	}

}

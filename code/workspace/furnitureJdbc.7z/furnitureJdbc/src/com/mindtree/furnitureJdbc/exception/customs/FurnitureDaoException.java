package com.mindtree.furnitureJdbc.exception.customs;

import com.mindtree.furnitureJdbc.exception.FurnitureAppException;

public class FurnitureDaoException extends FurnitureAppException {

	public FurnitureDaoException() {
		// TODO Auto-generated constructor stub
	}

	public FurnitureDaoException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FurnitureDaoException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FurnitureDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public FurnitureDaoException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
